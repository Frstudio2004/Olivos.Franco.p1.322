
package config;

import java.nio.file.Path;
import java.nio.file.Paths;


public interface RutasArchivos {
    
    static final String BASE = "src/data/";
    public static final String RUTA_BINARIO = "src/data/caso.bin";
    public static final String RUTA_CSV = "src/data/caso.csv";

    private static Path getRutaBIN() {
        return Paths.get(BASE, RUTA_BINARIO);
    }
    
   
    private static Path getRutaCSV() {
        return Paths.get(BASE, RUTA_CSV);
    }

    
    public static String getRutaBINString() {
        return getRutaBIN().toString(); 
    }
    
   
    public static String getRutaCSVString() {
        return getRutaCSV().toString();
    }
}
