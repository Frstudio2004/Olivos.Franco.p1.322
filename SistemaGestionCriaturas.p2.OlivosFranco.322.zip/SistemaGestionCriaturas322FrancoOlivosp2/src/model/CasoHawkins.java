package model;

import java.util.Objects;
import service.CSVSerializable;

public class CasoHawkins implements CSVSerializable, Comparable<CasoHawkins> {

    private static final long serialVersionUID = 1L;

    private int id; 
    private String titulo;
    private String investigador;
    private ClasificacionCaso clasificacion;

    public CasoHawkins(int id, String titulo, String investigador, ClasificacionCaso clasificacion) {
        this.id = id;
        this.titulo = titulo;
        this.investigador = investigador;
        this.clasificacion = clasificacion;
    }

    
    public int getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getInvestigador() { return investigador; }
    public ClasificacionCaso getClasificacion() { return clasificacion; }

    
    @Override
    public int compareTo(CasoHawkins otra) {
        return Integer.compare(this.id, otra.id);
    }
    
    public static String toCSVHeader() {
    return "ID,TITULO,INVESTIGADOR,CLASIFICACION";
    }
    
    @Override
    public String toCSV() {
        return id + "," + titulo + "," + investigador + "," + clasificacion.name();
    }
    
    public static CasoHawkins fromCSV(String csv) {
        String[] partes = csv.split(",");
        if (partes.length < 4) {
             throw new IllegalArgumentException("CSV incompleto para CasoHawkins: " + csv);
        }
        
        try {
            int id = Integer.parseInt(partes[0].trim());
            String titulo = partes[1].trim();
            String investigador = partes[2].trim();
            ClasificacionCaso clasificacion = ClasificacionCaso.valueOf(partes[3].trim().toUpperCase()); 
            
            return new CasoHawkins(id, titulo, investigador, clasificacion);
            
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Error al parsear línea CSV: " + csv, e);
        }
    }

    public static String toHeader() {
        return "id,titulo,investigador,clasificacion";
    }

    @Override
    public String toString() {
        return String.format("%-5d | %-30s | %-25s | %-10s", id, titulo, investigador, clasificacion.name());
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CasoHawkins caso = (CasoHawkins) o;
        return id == caso.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}