package model;

import java.io.*;
import java.util.*;
import java.util.function.*;
import service.CSVSerializable;



public class RegistroHawkins<T extends CSVSerializable & Comparable<T>> implements Serializable {

    private static final long serialVersionUID = 1L;
    private List<T> elementos;

    public RegistroHawkins() {
        this.elementos = new ArrayList<>();
    }
    

    public void agregar(T elemento) {
        if (!elementos.contains(elemento)) {
            elementos.add(elemento);
        }
    }

    public T obtener(int indice) {
        if (indice >= 0 && indice < elementos.size()) {
            return elementos.get(indice);
        }
        return null;
    }
    
    public void eliminar(int indice) {
        if (indice >= 0 && indice < elementos.size()) {
            elementos.remove(indice);
        }
    }

    
    public void paraCadaElemento(Consumer<T> consumidor) {
        elementos.forEach(consumidor);
    }
    
    
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrados = new ArrayList<>();
        for (T elemento : this.elementos) {
            if (criterio.test(elemento)) {
                filtrados.add(elemento);
            }
        }
        return filtrados;
    }

    // Ordenar (natural) 
    public void ordenar() {
        Collections.sort(elementos); 
    }

    // Ordenar (con Comparator) 
    public void ordenar(Comparator<T> comparator) {
        elementos.sort(comparator);
    }
    
    public void guardarEnArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {
            serializador.writeObject(this.elementos);
        } 
    }
    
    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream deserializador = new ObjectInputStream(new FileInputStream(path))) {
            Object objetoLeido = deserializador.readObject();
            
            if (objetoLeido instanceof List) {
                this.elementos = (List<T>) objetoLeido; 
            } 
            
        }
    }
    
    public void guardarEnCSV(String path) throws IOException, ClassNotFoundException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            
            if (!elementos.isEmpty() && elementos.get(0) instanceof CasoHawkins) {
             writer.write(CasoHawkins.toCSVHeader()); 
             writer.newLine();
            }
            for (T elemento : this.elementos) {
                writer.write(elemento.toCSV());
                writer.newLine();
            }
        }
    }
    
    public void cargarDesdeCSV(String ruta, Function<String, T> conversor) throws IOException, ClassNotFoundException {
        this.elementos = new ArrayList<>(); 
        
        try (BufferedReader reader = new BufferedReader(new FileReader(ruta))) {
            String linea;
            reader.readLine();
            
            while ((linea = reader.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    // Ahora usamos el nombre del método personalizado
                    T objeto = conversor.apply(linea); 
                    this.elementos.add(objeto);
                }
            } 
        } 
    }

}
    