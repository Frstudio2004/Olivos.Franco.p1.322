package sistemagestioncriaturas322francoolivos;

import java.io.IOException;
import model.CasoHawkins;
import model.ClasificacionCaso;
import model.RegistroHawkins;



public class SistemaGestionCriaturas {
    public static void main(String[] args) {
        try {
            RegistroHawkins<CasoHawkins> registro = new RegistroHawkins<>();

            System.out.println("\n------------------------ CARGA INICIAL DE DATOS ------------------------------");
            registro.agregar(new CasoHawkins(1, "Apertura cerca del laboratorio", "Dr. Brenner", ClasificacionCaso.APERTURA_DIMENSIONAL));
            registro.agregar(new CasoHawkins(2, "Actividad psiquica elevada", "Dr. Owens", ClasificacionCaso.SUJETO_PSIQUICO));
            registro.agregar(new CasoHawkins(3, "Rastros de entidad en Hawkins", "Jim Hopper", ClasificacionCaso.ENTIDAD_HOSTIL));
            registro.agregar(new CasoHawkins(4, "Seniales electromagneticas inusuales", "Nancy Wheeler", ClasificacionCaso.FENOMENO_ELECTROMAGNETICO));
            registro.agregar(new CasoHawkins(5, "Desaparicion de joven en bosque", "Joyce Byers", ClasificacionCaso.DESAPARICION));
            registro.agregar(new CasoHawkins(6, "Investigacion sobre portal", "Dr. Brenner", ClasificacionCaso.CONFIDENCIAL));


            
            System.out.println("\n------------------------- MOSTRAR TODOS LOS CASOS -----------------------------");
            System.out.println("Casos registrados:");
            System.out.println(CasoHawkins.toCSVHeader()); 
            registro.paraCadaElemento(c -> System.out.println(c)); 


            
            System.out.println("\n--------------- FILTRAR POR CLASIFICACION (SUJETO_PSIQUICO) --------------------");
            System.out.println("\nCasos tipo SUJETO_PSIQUICO:");
            System.out.println(CasoHawkins.toCSVHeader());
            registro.filtrar(c -> c.getClasificacion() == ClasificacionCaso.SUJETO_PSIQUICO) 
                    .forEach(c -> System.out.println(c)); 
            


           
            System.out.println("\n--------------- FILTRAR POR PALABRA EN TITULO (\"portal\") ---------------------");
            System.out.println("\nCasos que contienen 'portal':");
            System.out.println(CasoHawkins.toCSVHeader());
            registro.filtrar(c -> c.getTitulo().toLowerCase().contains("portal")) 
                    .forEach(c -> System.out.println(c)); 
            


            
            System.out.println("\n------------------------- ORDENAR POR ID (Natural) -----------------------------");
            System.out.println("\nCasos ordenados por ID (Natural):");
            registro.ordenar(); 
            System.out.println(CasoHawkins.toCSVHeader());
            registro.paraCadaElemento(c -> System.out.println(c)); 



            
            System.out.println("\n--------------------- ORDENAR POR TITULO (Comparator) ---------------------------");
            
            registro.ordenar((c1, c2) -> c1.getTitulo().compareTo(c2.getTitulo())); 
            System.out.println(CasoHawkins.toCSVHeader());
            registro.paraCadaElemento(c -> System.out.println(c)); 
            

            
            System.out.println("\n----------------- PERSISTENCIA BINARIA (Guardar y Cargar)) ----------------------");
            registro.guardarEnArchivo("src/data/casos.dat"); 
            RegistroHawkins<CasoHawkins> cargado = new RegistroHawkins<>();
            cargado.cargarDesdeArchivo("src/data/casos.dat");
            System.out.println("\nCasos cargados desde archivo binario:");
            System.out.println(CasoHawkins.toCSVHeader());
            cargado.paraCadaElemento(c -> System.out.println(c)); 
            

            
            System.out.println("\n------------------- PERSISTENCIA CSV (Guardar y Cargar) -------------------------");
            registro.guardarEnCSV("src/data/casos.csv"); 
            cargado.cargarDesdeCSV("src/data/casos.csv", csv -> CasoHawkins.fromCSV(csv)); 

            System.out.println("\nCasos cargados desde archivo CSV:");
            System.out.println(CasoHawkins.toCSVHeader());
            cargado.paraCadaElemento(c -> System.out.println(c)); 
            System.out.println("-------------------------------------------------------------------------------------");


        } catch (IOException | ClassNotFoundException e) {
            
            System.err.println("Error: " + e.getMessage());
        }
    }
}
