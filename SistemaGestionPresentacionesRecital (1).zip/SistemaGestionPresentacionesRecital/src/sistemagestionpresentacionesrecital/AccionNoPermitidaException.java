
package sistemagestionpresentacionesrecital;


public class AccionNoPermitidaException extends RuntimeException {

    
    public AccionNoPermitidaException(String nombrePresentacion, String accion) {
        super("La presentación '" + nombrePresentacion + "' no puede realizar la acción '" + accion + "'.");
    }

    
    public AccionNoPermitidaException(String msg) {
	super(msg);
    }
}
