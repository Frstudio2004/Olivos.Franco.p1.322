
package sistemagestionpresentacionesrecital;


public interface Animador {
    void animarPublico();
    
}
