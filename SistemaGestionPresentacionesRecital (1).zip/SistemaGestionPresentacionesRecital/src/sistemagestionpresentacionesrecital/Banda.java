
package sistemagestionpresentacionesrecital;


public class Banda extends Presentacion implements Tocable {
    private final int maxIntegrantes;
    
    public Banda(String nombre, String escenario, TipoEscenario tipoEscenario, int maxIntegrantes) {
	super(nombre, escenario, tipoEscenario);
	if (maxIntegrantes <= 0){
	    throw new IllegalArgumentException("El maximo de Integrantes debe ser mayor a 0");
	}
	this.maxIntegrantes = maxIntegrantes;
    }

    @Override
    public String getDetallesEspecificos() {
	return "Máx. Integrantes: " + maxIntegrantes;
    }
    
    @Override
    public void tocarEnVivo() {
	System.out.println("La banda " + getNombre() + "' está tocando un poderoso show en vivo.");
    }
    
    
}
