
package sistemagestionpresentacionesrecital;


public class DJ extends Presentacion implements Animador{
    private final String estiloMusicalPredominante;

    public DJ(String nombre, String escenario, TipoEscenario tipoEscenario, String estiloMusicalPredominante) {
        super(nombre, escenario, tipoEscenario);
        this.estiloMusicalPredominante = estiloMusicalPredominante;
    }

    @Override
    public String getDetallesEspecificos() {
        return "Estilo Musical: " + estiloMusicalPredominante;
    }
    
    @Override
    public void animarPublico() {
        System.out.println("El DJ " + getNombre() + " vuelve animal al público con " + estiloMusicalPredominante);
    }
    
}
