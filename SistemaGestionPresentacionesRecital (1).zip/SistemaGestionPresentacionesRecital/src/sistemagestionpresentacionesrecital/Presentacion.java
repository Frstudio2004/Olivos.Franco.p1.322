package sistemagestionpresentacionesrecital;

import java.util.Objects;

public abstract class Presentacion {
    private final String nombre;
    private final String escenario;
    private final TipoEscenario tipoEscenario;

    public Presentacion(String nombre, String escenario, TipoEscenario tipoEscenario) {
	validarNombre(nombre);
	validarEscenario(escenario);
        this.nombre = nombre;
        this.escenario = escenario;
        this.tipoEscenario = tipoEscenario;
    }
    
    private void validarEscenario(String escenario){
	if (escenario == null){
	    throw new IllegalArgumentException("El nombre del Escenario no puede ser nulo");
	} 
    }

    private void validarNombre(String nombre){
	if (nombre == null){
	    throw new IllegalArgumentException("El nombre de el/los presentadores no puede ser nulo");
	}
    }
    
    public String getNombre() {
        return nombre;
    }

    public String getEscenario() {
        return escenario;
    }

    public TipoEscenario getTipoEscenario() {
        return tipoEscenario;
    }

    public abstract String getDetallesEspecificos();
    
    
    public String mostrarDetalles() {
        return String.format("[Tipo: %s] Nombre: %s, Escenario: %s (%s). Detalles: %s",
                             this.getClass().getSimpleName(), nombre, escenario, tipoEscenario, getDetallesEspecificos());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj){
	    return true;
	}
        if (obj == null || !(obj instanceof Presentacion)){
	    return false;
	}
        Presentacion that = (Presentacion) obj;
        return Objects.equals(nombre, that.nombre) && Objects.equals(escenario, that.escenario);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, escenario);
    }
    
    @Override
    public String toString() {
	return "[Tipo: " + this.getClass() + 
		"] Nombre: " + nombre + 
		", Escenario: " + escenario + 
		" (" + tipoEscenario + "). Detalles: " + getDetallesEspecificos();
}
}