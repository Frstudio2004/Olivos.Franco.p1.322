
package sistemagestionpresentacionesrecital;


public class PresentacionDuplicadaException extends RuntimeException {

  
    public PresentacionDuplicadaException() {
    }

    public PresentacionDuplicadaException(String nombre, String escenario) {
        super("Error de Duplicidad: Ya existe una presentación con el nombre '" + nombre + 
              "' en el escenario '" + escenario + "'.");
    }

    public PresentacionDuplicadaException(String msg) {
	super(msg);
    }
}
