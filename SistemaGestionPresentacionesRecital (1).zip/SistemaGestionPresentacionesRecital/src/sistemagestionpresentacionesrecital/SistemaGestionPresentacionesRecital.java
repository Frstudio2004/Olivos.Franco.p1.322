
package sistemagestionpresentacionesrecital;


public class SistemaGestionPresentacionesRecital {

    public static void main(String[] args) {
        SistemaRecital sistema = new SistemaRecital();

        Banda b1 = new Banda("Los Relámpagos", "Escenario Principal", TipoEscenario.EXTERIOR, 5);
        Solista s1 = new Solista("Luna", "Carpa Acústica", TipoEscenario.INTERIOR, "Guitarra");
        DJ dj1 = new DJ("BeatsMaster", "Escenario Principal", TipoEscenario.EXTERIOR, "Techno");
        Banda b2 = new Banda("Rocketeers", "Escenario Secundario", TipoEscenario.EXTERIOR, 4);
        Solista s2 = new Solista("Clara", "Escenario Secundario", TipoEscenario.EXTERIOR, "Piano");
	//Banda b1_duplicado = new Banda("Los Relámpagos", "Escenario Principal", TipoEscenario.EXTERIOR, 3);


        System.out.println("\n--- Prueba de Excepcion (Duplicado) ---");
        try {
	    sistema.agregarPresentacion(b1);
	    sistema.agregarPresentacion(s1);
	    sistema.agregarPresentacion(dj1);
	    sistema.agregarPresentacion(b2);
	    sistema.agregarPresentacion(s2);
        } catch (PresentacionDuplicadaException e) {
            System.err.println(" EXCEPCIÓN CAPTURADA: " + e.getMessage());
        }
        System.out.println("---------------------------------------");

        //sistema.agregarPresentacion(b1_duplicado); 
        sistema.mostrarPresentaciones();

       
        System.out.println("\n--- Prueba de Acciones (VIVO y ANIMAR) ---");
        
      
        sistema.ejecutarTocarEnVivo(s1);
        sistema.ejecutarAnimarPublico(s1);
        sistema.ejecutarAnimarPublico(dj1);
        //try {
        //    sistema.ejecutarAnimarPublico(b1);
        //} catch (AccionNoPermitidaException e) {
        //    System.err.println("EXCEPCIÓN CAPTURADA: " + e.getMessage());
        //}
        //System.out.println("-----------------------------------------");
        
       
        //sistema.filtrarPorTipoEscenario(TipoEscenario.INTERIOR);
        //sistema.filtrarPorTipoEscenario(TipoEscenario.EXTERIOR);

       
        //sistema.eliminarPresentacionesPorTipo("Solista"); 
        
       
        //sistema.mostrarPresentaciones();
        
        
        //sistema.eliminarPresentacionesPorTipo("Banda");
        
       
        //sistema.eliminarPresentacionesPorTipo("DJ");
        
        
        //sistema.mostrarPresentaciones();
    }
}
