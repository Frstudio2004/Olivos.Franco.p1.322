
package sistemagestionpresentacionesrecital;
import java.util.List;
import java.util.ArrayList;

public class SistemaRecital  {
    private final List<Presentacion> presentaciones;

    public SistemaRecital() {
        this.presentaciones = new ArrayList<>();
    }

    
    public void agregarPresentacion(Presentacion presentacion) {
        if (presentaciones.contains(presentacion)) { 
	    throw new PresentacionDuplicadaException(presentacion.getNombre(), presentacion.getEscenario());
        }
        presentaciones.add(presentacion);
        System.out.println("Presentacion agregada: " + presentacion.getNombre() + " ( " + presentacion.getClass() + ").");
    }

    public void mostrarPresentaciones() {
        if (presentaciones.isEmpty()) {
            System.out.println("No hay presentaciones registradas.");
            return;
        }
        System.out.println("\n--- REGISTRO DE PRESENTACIONES ---:");
        for (Presentacion p : presentaciones) {
            System.out.println(p); 
            System.out.println("------------------------------------");
        }
    }

   
    public void ejecutarTocarEnVivo(Presentacion presentacion) {
        if (presentacion instanceof Tocable tocable) {
            tocable.tocarEnVivo();
        } else {
            throw new AccionNoPermitidaException(presentacion.getNombre(), "tocar en vivo");
            }
    }

    public void ejecutarAnimarPublico(Presentacion presentacion) {
        if (presentacion instanceof Animador animador) {
            animador.animarPublico();
        } else {
            throw new AccionNoPermitidaException(presentacion.getNombre(), "animar al público");
            }
    }
    
       
    
    public List<Presentacion> filtrarPorTipoEscenario(TipoEscenario tipo) {
        List<Presentacion> filtradas = new ArrayList<>();
        
        for (Presentacion p : presentaciones) {
            if (p.getTipoEscenario() == tipo) {
                filtradas.add(p);
            }
        }
        
        System.out.println("\n--- FILTRADO POR ESCENARIO " + tipo + " (Total: " + filtradas.size() + ") ---");
        if (filtradas.isEmpty()) {
            System.out.println("No se encontraron presentaciones en ese tipo de escenario.");
        } else {
            for (Presentacion p : filtradas) {
                System.out.println(p); 
            }
        }
        System.out.println("------------------------------------");
        return filtradas;
    }

    
    public int eliminarPresentacionesPorTipo(String tipoPresentacion) {
        String tipoBuscado = tipoPresentacion.trim();
        
        List<Presentacion> aEliminar = new ArrayList<>();
        
        
        for (Presentacion p : presentaciones) {
            if (p.getClass().getSimpleName().equalsIgnoreCase(tipoBuscado)) {
                aEliminar.add(p);
            }
        }
        
        int eliminadas = aEliminar.size();
        
        if (eliminadas > 0) {
            presentaciones.removeAll(aEliminar);
            
            System.out.println("\n[ELIMINACIÓN] Se eliminaron " + eliminadas + " presentaciones del tipo '" + tipoBuscado + "'.");
        } else {
            System.out.println("\n[ELIMINACIÓN] ️No se encontraron presentaciones del tipo '" + tipoBuscado + "' para eliminar.");
        }
        
        return eliminadas;
    }
}

    
