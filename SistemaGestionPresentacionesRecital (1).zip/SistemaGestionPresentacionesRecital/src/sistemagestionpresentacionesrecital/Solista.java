
package sistemagestionpresentacionesrecital;


public class Solista extends Presentacion implements Tocable, Animador{
    private final String instrumentoPrincipal;
    
    public Solista(String nombre, String escenario, TipoEscenario tipoEscenario, String instrumentoPrincipal) {
        super(nombre, escenario, tipoEscenario);
        this.instrumentoPrincipal = instrumentoPrincipal;
    }
    
    @Override
    public String getDetallesEspecificos() {
        return "Instrumento Principal: " + instrumentoPrincipal;
    }
    
    @Override
    public void tocarEnVivo() {
	System.out.println("El solista " + getNombre() + "' está tocando un poderoso show en vivo con su "+ instrumentoPrincipal + ".");
    }
    
    
    @Override
    public void animarPublico() {
        System.out.println("El solista " + getNombre() + "' pide un aplauso al público. ¡Arriba las manos!");
    }
    
}
