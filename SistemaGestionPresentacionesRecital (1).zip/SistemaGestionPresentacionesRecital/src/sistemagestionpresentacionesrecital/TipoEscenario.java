
package sistemagestionpresentacionesrecital;



public enum TipoEscenario {
    INTERIOR,
    EXTERIOR
    
}
