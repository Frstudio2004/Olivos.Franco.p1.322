
package sistemagestionpresentacionesrecital;


public interface Tocable {
    void tocarEnVivo();
    
}
