package sistemaproyectos.p1.olivos.franco.pkg322;


public interface Actualizable {
    void actualizarResultados();
    
}
