package sistemaproyectos.p1.olivos.franco.pkg322;

public class AnalisisEstadistico extends Proyecto implements Actualizable {
    private final TipoAnalisis tipoAnalisis;

    public AnalisisEstadistico(String nombre, String equipoResponsable, EstadoProyecto estadoActual, TipoAnalisis tipoAnalisis) {
        super(nombre, equipoResponsable, estadoActual);
        validarAnalisis(nombre);
        this.tipoAnalisis = tipoAnalisis;
    }
    
    private void validarAnalisis(String nombre){
	if (nombre == null){
	    throw new IllegalArgumentException("El tipo de analisis no puede ser nulo");
	}
    }

    public TipoAnalisis getTipoAnalisis() {
        return tipoAnalisis;
    }

    
    @Override
    public void actualizarResultados() {
        System.out.println("Actualizando Análisis '" + getNombre() + 
                   "' (equipo: " + getEquipoResponsable() + 
                   "): tipo=" + tipoAnalisis);
    }

    @Override
    public String toString() {
    return super.toString() + ", tipoAnalisis=" + tipoAnalisis;
    }
}

