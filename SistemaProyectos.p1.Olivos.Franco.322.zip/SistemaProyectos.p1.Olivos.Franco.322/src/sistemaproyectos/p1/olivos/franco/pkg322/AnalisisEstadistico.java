package sistemaproyectos.p1.olivos.franco.pkg322;

public class AnalisisEstadistico extends Proyecto implements Actualizable {
    private final TipoAnalisis tipoAnalisis;

    public AnalisisEstadistico(String nombre, String equipoResponsable, EstadoProyecto estadoActual, TipoAnalisis tipoAnalisis) {
        super(nombre, equipoResponsable, estadoActual);
        validarAnalisis(nombre);
        this.tipoAnalisis = tipoAnalisis;
    }
    
    public void validarAnalisis(String nombre){
	if (nombre == null){
	    throw new IllegalArgumentException("El tipo de analisis no puede ser nulo");
	}
    }

    public TipoAnalisis getTipoAnalisis() {
        return tipoAnalisis;
    }

    
    @Override
    public void actualizarResultados() {
        System.out.println(String.format("Actualizando Análisis '%s' (equipo: %s): tipo=%s",
                getNombre(), getEquipoResponsable(), tipoAnalisis));
    }

    @Override
    public String toString() {
        return String.format("%s, tipoAnalisis=%s", super.toString(), tipoAnalisis);
    }
}

