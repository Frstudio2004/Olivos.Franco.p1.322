/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package sistemaproyectos.p1.olivos.franco.pkg322;

/**
 *
 * @author Usuario
 */
public class DuplicateProjectException extends Exception {

    /**
     * Creates a new instance of <code>DuplicateProjectException</code> without
     * detail message.
     */
    public DuplicateProjectException() {
    }

    /**
     * Constructs an instance of <code>DuplicateProjectException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public DuplicateProjectException(String msg) {
	super(msg);
    }
}
