
package sistemaproyectos.p1.olivos.franco.pkg322;


public class DuplicateProjectException extends RuntimeException {

    private final String nombreProyectoDuplicado;

    public DuplicateProjectException(String nombre) {
	super("Duplicado detectado.");
	this.nombreProyectoDuplicado = nombre;
    }
    
    public String getNombreDuplicado() {
        return nombreProyectoDuplicado;
    }
}
