package sistemaproyectos.p1.olivos.franco.pkg322;

import java.text.DecimalFormat;


public class ModeloMachineLearning extends Proyecto implements Actualizable {
    private double precision; 

    public ModeloMachineLearning(String nombre, String equipoResponsable, EstadoProyecto estadoActual, double precision) {
        super(nombre, equipoResponsable, estadoActual);
        validarPrecision(precision);
    }

    public double getPrecision() {
        return precision;
    }

    public void validarPrecision(double precision) {
        if (precision < 0 || precision > 100) {
            throw new IllegalArgumentException("La precisión debe estar entre 0 y 100");
        }
        this.precision = precision;
    }

    @Override
    public void actualizarResultados() {
        double antigua = this.precision;
        if (precision < 100.0) {
            precision = Math.min(100.0, precision + 1.0);
        }
        DecimalFormat df = new DecimalFormat("#.##");
        System.out.println(String.format("Actualizando Modelo '%s' (equipo: %s): precision %s -> %s",
                getNombre(), getEquipoResponsable(), df.format(antigua), df.format(precision)));
    }

    @Override
    public String toString() {
        return String.format("%s, precision=%.2f%%", super.toString(), precision);
    }
}
