package sistemaproyectos.p1.olivos.franco.pkg322;

public class ModeloMachineLearning extends Proyecto implements Actualizable {
    private double precision; 
    private static final double MAX_PRECISION = 100.0;

    public ModeloMachineLearning(String nombre, String equipoResponsable, EstadoProyecto estadoActual, double precision) {
        super(nombre, equipoResponsable, estadoActual);
        validarPrecision(precision);
    }

    public double getPrecision() {
        return precision;
    }

    private void validarPrecision(double precision) {
        if (precision < 0 || precision > 100) {
            throw new IllegalArgumentException("La precisión debe estar entre 0 y 100");
        }
        this.precision = precision;
    }

    @Override
    public void actualizarResultados() {
    double antigua = this.precision;
    
    if (precision < MAX_PRECISION) {
        double nuevoValor = precision + 1.0;
	precision = (nuevoValor > MAX_PRECISION) ? MAX_PRECISION : nuevoValor;
    }
    
    System.out.println("Actualizando Modelo '" + getNombre() + 
                       "' (equipo: " + getEquipoResponsable() + 
                       "): precision " + antigua + " -> " + precision);
}

    @Override
    public String toString() {
    return super.toString() + ", precision=" + precision + "%";
    }
}
