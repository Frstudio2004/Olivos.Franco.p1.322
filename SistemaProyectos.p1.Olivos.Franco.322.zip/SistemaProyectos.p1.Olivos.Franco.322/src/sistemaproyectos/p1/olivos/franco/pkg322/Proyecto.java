package sistemaproyectos.p1.olivos.franco.pkg322;

import java.util.Objects;

public abstract class Proyecto {
    private final String nombre;
    private final String equipoResponsable;
    private EstadoProyecto estadoActual;

    public Proyecto(String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
	validarNombre(nombre);
	validarEquipoResponsable(equipoResponsable);
        this.nombre = nombre;
        this.equipoResponsable = equipoResponsable;
        this.estadoActual = estadoActual;
    }
    
    public void validarEquipoResponsable(String equipoResponsable){
	if (equipoResponsable == null){
	    throw new IllegalArgumentException("El equipo responsable no puede ser nulo");
	} 
    }

    public void validarNombre(String nombre){
	if (nombre == null){
	    throw new IllegalArgumentException("El nombre de proyecto no puede ser nulo");
	}
    }
    
    public String getNombre() {
        return nombre;
    }

    public String getEquipoResponsable() {
        return equipoResponsable;
    }

    public EstadoProyecto getEstadoActual() {
        return estadoActual;
    }

    public void setEstadoActual(EstadoProyecto nuevoEstado) {
        this.estadoActual = nuevoEstado;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Proyecto proyecto = (Proyecto) o;
        return nombre.equalsIgnoreCase(proyecto.nombre)
                && equipoResponsable.equalsIgnoreCase(proyecto.equipoResponsable);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre.toLowerCase(), equipoResponsable.toLowerCase());
    }
}