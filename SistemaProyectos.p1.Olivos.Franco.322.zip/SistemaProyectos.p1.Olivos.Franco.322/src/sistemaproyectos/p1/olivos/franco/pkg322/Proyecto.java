package sistemaproyectos.p1.olivos.franco.pkg322;

import java.util.Objects;

public abstract class Proyecto {
    private final String nombre;
    private final String equipoResponsable;
    private EstadoProyecto estadoActual;

    public Proyecto(String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
	validarNombre(nombre);
	validarEquipoResponsable(equipoResponsable);
        this.nombre = nombre;
        this.equipoResponsable = equipoResponsable;
        this.estadoActual = estadoActual;
    }
    
    private void validarEquipoResponsable(String equipoResponsable){
	if (equipoResponsable == null){
	    throw new IllegalArgumentException("El equipo responsable no puede ser nulo");
	} 
    }

    private void validarNombre(String nombre){
	if (nombre == null){
	    throw new IllegalArgumentException("El nombre de proyecto no puede ser nulo");
	}
    }
    
    public String getNombre() {
        return nombre;
    }

    public String getEquipoResponsable() {
        return equipoResponsable;
    }

    public EstadoProyecto getEstadoActual() {
        return estadoActual;
    }

    public void setEstadoActual(EstadoProyecto nuevoEstado) {
        this.estadoActual = nuevoEstado;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) { 
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) { 
            return false;
        }
        Proyecto otroProyecto = (Proyecto) obj;
        return Objects.equals(nombre, otroProyecto.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre.toLowerCase(), equipoResponsable.toLowerCase());
    }
    
    @Override
    public String toString() {
    return "Nombre de proyecto: " + nombre + "Equipo responsable: " + equipoResponsable + "Estado: " + estadoActual;
    
    }
}