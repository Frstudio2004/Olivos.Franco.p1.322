package sistemaproyectos.p1.olivos.franco.pkg322;

import java.util.ArrayList;
import java.util.List;


public class RegistroProyectos  {
    private final List<Proyecto> proyectos;

    public RegistroProyectos() {
        this.proyectos = new ArrayList<>();
    }

    
    public void agregarProyecto(Proyecto proyecto) {
        if (proyectos.contains(proyecto)) { 
	    throw new DuplicateProjectException(proyecto.getNombre());
        }
        proyectos.add(proyecto);
        System.out.println("Proyecto agregado: " + proyecto.getNombre() + " (equipo: " + proyecto.getEquipoResponsable() + ")");
    }

    public void mostrarProyectos() {
        if (proyectos.isEmpty()) {
            System.out.println("No hay proyectos registrados.");
            return;
        }
        System.out.println("Proyectos registrados:");
        for (Proyecto p : proyectos) {
            String detalle = p.toString();
            System.out.println(" - " + detalle);
        }
    }

   
    public void actualizarResultadosProyectos() {
        if (proyectos.isEmpty()) {
            System.out.println("No hay proyectos registrados para actualizar resultados.");
            return;
        }
        for (Proyecto p : proyectos) {
            if (p instanceof Actualizable actualizable) {
                actualizable.actualizarResultados();
            } else {
                System.out.println("El proyecto '" + p.getNombre() + "' (equipo: " + p.getEquipoResponsable() + ") no puede actualizar resultados directamente (SistemaVisualizacion).");
            }
        }
    }

    public void actualizarEstadoProyectos(EstadoProyecto nuevoEstado) {
        if (nuevoEstado == null) {
            System.out.println("No se realizó ninguna modificación: el nuevo estado es nulo.");
            return;
        }
        if (proyectos.isEmpty()) {
            System.out.println("No se realizó ninguna modificación: no hay proyectos registrados.");
            return;
        }
        int contador = 0;
        for (Proyecto p : proyectos) {
            EstadoProyecto anterior = p.getEstadoActual();
            if (anterior != nuevoEstado) {
                p.setEstadoActual(nuevoEstado);
                System.out.println("Proyecto '" + p.getNombre() + "' (equipo: " + p.getEquipoResponsable() + 
                   "): estado " + anterior + " -> " + nuevoEstado);
		contador++;
            }
        }
        if (contador == 0) {
            System.out.println("No se realizó ninguna modificación: ningún proyecto cambió de estado.");
        } else {
            System.out.println("Total de proyectos actualizados: " + contador);
        }
    }

    
    public List<Proyecto> getProyectos() {
        return new ArrayList<>(proyectos);
    }
}