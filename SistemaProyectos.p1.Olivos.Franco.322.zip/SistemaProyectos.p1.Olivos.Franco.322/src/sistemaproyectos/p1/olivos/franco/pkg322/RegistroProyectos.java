package sistemaproyectos.p1.olivos.franco.pkg322;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class RegistroProyectos {
    private final List<Proyecto> proyectos;

    public RegistroProyectos() {
        this.proyectos = new ArrayList<>();
    }

    
    public void agregarProyecto(Proyecto proyecto) throws DuplicateProjectException {
        Objects.requireNonNull(proyecto, "El proyecto no puede ser nulo");
        boolean existe = proyectos.stream()
                .anyMatch(p -> p.getNombre().equalsIgnoreCase(proyecto.getNombre())
                        && p.getEquipoResponsable().equalsIgnoreCase(proyecto.getEquipoResponsable()));
        if (existe) {
            throw new DuplicateProjectException(String.format(
                    "Ya existe un proyecto con nombre '%s' y equipo '%s'",
                    proyecto.getNombre(), proyecto.getEquipoResponsable()));
        }
        proyectos.add(proyecto);
        System.out.println(String.format("Proyecto agregado: %s (equipo: %s)", proyecto.getNombre(), proyecto.getEquipoResponsable()));
    }

    public void mostrarProyectos() {
        if (proyectos.isEmpty()) {
            System.out.println("No hay proyectos registrados.");
            return;
        }
        System.out.println("Proyectos registrados:");
        for (Proyecto p : proyectos) {
            String detalle = p.toString();
            System.out.println(" - " + detalle);
        }
    }

    /**
     * Actualiza resultados de los proyectos que implementan Actualizable.
     * Informa de los que no pueden actualizarse directamente (SistemaVisualizacion).
     */
    public void actualizarResultadosProyectos() {
        if (proyectos.isEmpty()) {
            System.out.println("No hay proyectos registrados para actualizar resultados.");
            return;
        }
        for (Proyecto p : proyectos) {
            if (p instanceof Actualizable) {
                ((Actualizable) p).actualizarResultados();
            } else {
                System.out.println(String.format("El proyecto '%s' (equipo: %s) no puede actualizar resultados directamente (SistemaVisualizacion).",
                        p.getNombre(), p.getEquipoResponsable()));
            }
        }
    }

    /**
     * Actualiza el estado de todos los proyectos al nuevo estado indicado.
     * Muestra los cambios realizados y la cantidad total actualizada.
     * Si nuevoEstado es nulo, no hay proyectos o no se realizó ninguna modificación,
     * informa claramente.
     */
    public void actualizarEstadoProyectos(EstadoProyecto nuevoEstado) {
        if (nuevoEstado == null) {
            System.out.println("No se realizó ninguna modificación: el nuevo estado es nulo.");
            return;
        }
        if (proyectos.isEmpty()) {
            System.out.println("No se realizó ninguna modificación: no hay proyectos registrados.");
            return;
        }
        int contador = 0;
        for (Proyecto p : proyectos) {
            EstadoProyecto anterior = p.getEstadoActual();
            if (anterior != nuevoEstado) {
                p.setEstadoActual(nuevoEstado);
                System.out.println(String.format("Proyecto '%s' (equipo: %s): estado %s -> %s",
                        p.getNombre(), p.getEquipoResponsable(), anterior, nuevoEstado));
                contador++;
            }
        }
        if (contador == 0) {
            System.out.println("No se realizó ninguna modificación: ningún proyecto cambió de estado.");
        } else {
            System.out.println(String.format("Total de proyectos actualizados: %d", contador));
        }
    }

    // Getter para pruebas o uso externo
    public List<Proyecto> getProyectos() {
        return new ArrayList<>(proyectos);
    }
}