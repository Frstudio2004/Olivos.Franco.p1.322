
package sistemaproyectos.p1.olivos.franco.pkg322;


public class SistemaProyectosP1OlivosFranco322 {

    
    public static void main(String[] args) {
	RegistroProyectos registro = new RegistroProyectos();
	
	AnalisisEstadistico a1 = new AnalisisEstadistico("Comportamiento de Usuarios", "DataLab-B", EstadoProyecto.EN_DESARROLLO, TipoAnalisis.PREDICTIVO);

        ModeloMachineLearning m1 = new ModeloMachineLearning("Clasificador de Imagenes", "ML-Team", EstadoProyecto.ENTRENANDO_MODELO, 78.5);
        
        SistemaVisualizacion s1 = new SistemaVisualizacion("Dashboard de Ventas", "Viz-Team", EstadoProyecto.EN_DESARROLLO, 5);
	
	//AnalisisEstadistico a2_duplicado = new AnalisisEstadistico("Comportamiento de Usuarios", "Otro-Equipo", EstadoProyecto.FINALIZADO, TipoAnalisis.DESCRIPTIVO);
            
        
	try {
	    registro.agregarProyecto(a1);
	    registro.agregarProyecto(m1);
	    registro.agregarProyecto(s1);
	    //registro.agregarProyecto(a2_duplicado);
	    //System.out.println(); 
	    //registro.mostrarProyectos();
	    //System.out.println();
	    //registro.actualizarResultadosProyectos();
	    //System.out.println();
	    //registro.actualizarEstadoProyectos(EstadoProyecto.FINALIZADO);
	    //System.out.println();
	    //registro.actualizarEstadoProyectos(null);
	    
	} catch(DuplicateProjectException e){
	    String nombre = e.getNombreDuplicado();
            
            System.err.println("\n Error en el registro de proyectos.");
            System.err.println("**Motivo:** No se pudo agregar el proyecto porque ya existe un registro con el nombre **'" + nombre + "'**.");
            System.err.println("Por favor, utilice un nombre unico.");
	}
	
	
	
    }

}
