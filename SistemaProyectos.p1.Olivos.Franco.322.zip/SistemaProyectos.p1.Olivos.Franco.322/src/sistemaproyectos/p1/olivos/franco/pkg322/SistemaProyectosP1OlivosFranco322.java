
package sistemaproyectos.p1.olivos.franco.pkg322;


public class SistemaProyectosP1OlivosFranco322 {

    
    public static void main(String[] args) throws DuplicateProjectException {
	RegistroProyectos registro = new RegistroProyectos();
	
	AnalisisEstadistico a1 = new AnalisisEstadistico("Comportamiento de Usuarios", "DataLab-B", EstadoProyecto.EN_DESARROLLO, TipoAnalisis.PREDICTIVO);
        registro.agregarProyecto(a1);

        ModeloMachineLearning m1 = new ModeloMachineLearning("Clasificador de Imagenes", "ML-Team", EstadoProyecto.ENTRENANDO_MODELO, 78.5);
        registro.agregarProyecto(m1);

        SistemaVisualizacion s1 = new SistemaVisualizacion("Dashboard de Ventas", "Viz-Team", EstadoProyecto.EN_DESARROLLO, 5);
        registro.agregarProyecto(s1);
	
	//System.out.println();
        //registro.mostrarProyectos
		
	//System.out.println();
        //registro.actualizarResultadosProyectos();
	
	System.out.println();
        registro.actualizarEstadoProyectos(EstadoProyecto.FINALIZADO);
	
    }
    
    
    
}
