package sistemaproyectos.p1.olivos.franco.pkg322;


public class SistemaVisualizacion extends Proyecto {
    private int cantidadGraficos;

    public SistemaVisualizacion(String nombre, String equipoResponsable, EstadoProyecto estadoActual, int cantidadGraficos) {
        super(nombre, equipoResponsable, estadoActual);
        validarCantidadGraficos(cantidadGraficos);
    }

    public int getCantidadGraficos() {
        return cantidadGraficos;
    }

    public void validarCantidadGraficos(int cantidadGraficos) {
        if (cantidadGraficos <= 0) {
            throw new IllegalArgumentException("La cantidad de gráficos debe ser mayor a 0");
        }
        this.cantidadGraficos = cantidadGraficos;
    }

    @Override
    public String toString() {
        return String.format("%s, cantidadGraficos=%d", super.toString(), cantidadGraficos);
    }
}