package sistemaproyectos.p1.olivos.franco.pkg322;


public enum TipoAnalisis {
    DESCRIPTIVO,
    INFERENCIAL,
    PREDICTIVO  
}
